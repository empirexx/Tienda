package edu.vedoque.seguridadbase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeguridadbaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeguridadbaseApplication.class, args);
    }

}
